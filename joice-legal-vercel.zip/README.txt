JOICE Automation — páginas legais

Arquivos:
- /index.html
- /privacidade/index.html
- /exclusao-de-dados/index.html

Na Vercel, depois do deploy, use:
- https://SEU-PROJETO.vercel.app/privacidade/
- https://SEU-PROJETO.vercel.app/exclusao-de-dados/

Essas duas URLs podem ser usadas nos campos da Meta.
